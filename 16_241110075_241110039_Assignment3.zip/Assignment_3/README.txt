DATASET FILE: tornado3d_vector.vti

Open CMD;
cd <current directory>

commands to run code:

finalanswer.py --seed_x 0 --seed_y 0 --seed_z 7 --visualize yes

finalanswer.py --seed_x 0 --seed_y 0 --seed_z 7 

The first command will open the visualization to open, while the second command will only write the output file

You can change the seed parameters as you wish

Output is "Output.vtp" File

