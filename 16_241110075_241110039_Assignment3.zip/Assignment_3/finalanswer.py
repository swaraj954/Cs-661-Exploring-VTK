import argparse
import numpy as np
from vtk import (
    vtkXMLImageDataReader, vtkXMLPolyDataWriter, vtkProbeFilter,
    vtkPoints, vtkPolyData, vtkCellArray, vtkPolyDataMapper,
    vtkActor, vtkRenderer, vtkRenderWindow, vtkRenderWindowInteractor
)

# Load the 3D vector field data
volume_reader = vtkXMLImageDataReader()
volume_reader.SetFileName("tornado3d_vector.vti")
volume_reader.Update()
volume_data = volume_reader.GetOutput()

# Setup probe filter to extract vector values at arbitrary points
vector_probe = vtkProbeFilter()
vector_probe.SetSourceData(volume_data)

# Parse command-line input arguments
parser = argparse.ArgumentParser(description="Generate streamline from seed point.")
parser.add_argument("--seed_x", type=float, required=True)
parser.add_argument("--seed_y", type=float, required=True)
parser.add_argument("--seed_z", type=float, required=True)
parser.add_argument("--visualize", type=str, default="no", help="Enable rendering")
args = parser.parse_args()

seed_point = [args.seed_x, args.seed_y, args.seed_z]
render_enabled = args.visualize.lower() == "yes"

# Integration parameters
max_steps = 1000
step_size = 0.05

# Retrieve bounds for safety checks
bounds = volume_data.GetBounds()

def is_within_bounds(point):
    x, y, z = point
    return (bounds[0] <= x <= bounds[1]) and (bounds[2] <= y <= bounds[3]) and (bounds[4] <= z <= bounds[5])

def interpolate_vector_at(position):
    pts = vtkPoints()
    pts.InsertNextPoint(position)
    
    temp_data = vtkPolyData()
    temp_data.SetPoints(pts)
    
    vector_probe.SetInputData(temp_data)
    vector_probe.Update()

    vector_array = vector_probe.GetOutput().GetPointData().GetArray("vectors")
    return np.array(vector_array.GetTuple(0))

def trace_streamline(seed, direction):
    points = []
    pos = np.array(seed)

    if not is_within_bounds(pos):
        return points

    for _ in range(max_steps):
        k1 = step_size * direction * interpolate_vector_at(pos)
        k2 = step_size * direction * interpolate_vector_at(pos + 0.5 * k1)
        k3 = step_size * direction * interpolate_vector_at(pos + 0.5 * k2)
        k4 = step_size * direction * interpolate_vector_at(pos + k3)

        next_pos = pos + (k1 + 2*k2 + 2*k3 + k4) / 6.0
        if not is_within_bounds(next_pos):
            break

        points.append(next_pos.tolist())
        pos = next_pos

    return points

# Generate both forward and backward streamlines
forward_path = trace_streamline(seed_point, direction=1)
backward_path = trace_streamline(seed_point, direction=-1)
full_path = backward_path[::-1] + [seed_point] + forward_path

# Convert to VTK points and lines
vtk_stream_points = vtkPoints()
vtk_stream_lines = vtkCellArray()

for idx, coord in enumerate(full_path):
    pid = vtk_stream_points.InsertNextPoint(coord)
    if idx > 0:
        vtk_stream_lines.InsertNextCell(2)
        vtk_stream_lines.InsertCellPoint(idx - 1)
        vtk_stream_lines.InsertCellPoint(idx)

stream_data = vtkPolyData()
stream_data.SetPoints(vtk_stream_points)
stream_data.SetLines(vtk_stream_lines)

# Save to .vtp file
stream_writer = vtkXMLPolyDataWriter()
stream_writer.SetFileName("output.vtp")
stream_writer.SetInputData(stream_data)
stream_writer.Write()


if render_enabled:
    mapper = vtkPolyDataMapper()
    mapper.SetInputData(stream_data)

    actor = vtkActor()
    actor.SetMapper(mapper)
    actor.GetProperty().SetColor(0.0, 0.75, 0.0)  # Green line
    actor.GetProperty().SetLineWidth(3)

    renderer = vtkRenderer()
    renderer.AddActor(actor)
    renderer.SetBackground(1.0, 1.0, 1.0)

    render_window = vtkRenderWindow()
    render_window.AddRenderer(renderer)
    render_window.SetSize(800, 750)

    interactor = vtkRenderWindowInteractor()
    interactor.SetRenderWindow(render_window)

    render_window.Render()
    interactor.Start()
