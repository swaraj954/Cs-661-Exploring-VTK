import vtk
import sys

def render_volume(input_file, phong_requested):
    # Read Input Data
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName(input_file)  
    reader.Update()

    #Configure Color Transfer Function
    colors = vtk.vtkColorTransferFunction()


    # Add RGB control points (Data Value, Red, Green, Blue)
    #Dark Blue,Cyan,Blue,Red orange Yellow respectively
    colors.AddRGBPoint(-1873.9,  0.0, 0.0, 0.5)
    colors.AddRGBPoint(-4931.54, 0.0, 1.0, 1.0)   
    colors.AddRGBPoint(-2508.95, 0.0, 0.0, 1.0)   
       
    colors.AddRGBPoint(-1027.16, 1.0, 0.0, 0.0)   
    colors.AddRGBPoint(-298.031, 1.0, 0.4, 0.0)   
    colors.AddRGBPoint(2594.97,  1.0, 1.0, 0.0)   

    #Configure Opacity Transfer Function
    
    opacity_amount = vtk.vtkPiecewiseFunction()


    #Add opacity control points (Data Value, Opacity)
    opacity_amount.AddPoint(-4931.54, 1.0)    
    opacity_amount.AddPoint(101.815,  0.002)  
    opacity_amount.AddPoint(2594.97,  0.0)    


    # Set Up Volume Properties
    
    vp = vtk.vtkVolumeProperty()
    vp.SetColor(colors)          
    vp.SetScalarOpacity(opacity_amount) 
    vp.SetInterpolationTypeToLinear()

    # Configure Phong shading if requested
    

    if phong_requested:
        vp.ShadeOn()                
        vp.SetAmbient(0.5)          
        vp.SetDiffuse(0.5)          
        vp.SetSpecular(0.5)

    #  Create Volume Mapper

    mppr = vtk.vtkSmartVolumeMapper()
    mppr.SetInputConnection(reader.GetOutputPort())  


    #Create Volume Actor
    volume = vtk.vtkVolume()
    volume.SetMapper(mppr)           
    volume.SetProperty(vp)

    #Add Bounding Box Outline

    outline = vtk.vtkOutlineFilter()
    outline.SetInputConnection(reader.GetOutputPort()) 

    outline_mppr = vtk.vtkPolyDataMapper()
    outline_mppr.SetInputConnection(outline.GetOutputPort())

    o_actor = vtk.vtkActor()
    o_actor.SetMapper(outline_mppr)
    o_actor.GetProperty().SetColor(1, 1, 1)  

    #Set Up Rendering Window
    renderer = vtk.vtkRenderer()
    renderer.AddVolume(volume)          
    renderer.AddActor(o_actor)    
    renderer.SetBackground(0.2, 0.3, 0.4)  

    rw = vtk.vtkRenderWindow()
    rw.SetSize(1000, 1000)   
    rw.AddRenderer(renderer)

    #Enable Interaction
    user_interaction = vtk.vtkRenderWindowInteractor()
    user_interaction.SetRenderWindow(rw)
    user_interaction.Initialize()  
    user_interaction.Start()

#get input from cmd
def main():
    if len(sys.argv) != 3:
        print("Usage: python script.py inputfile.vti 0/1")
        sys.exit(1)

    input_file = sys.argv[1]
    phong_requested = int(sys.argv[2]) == 1  

    render_volume(input_file, phong_requested)

if __name__ == "__main__":
    main()
