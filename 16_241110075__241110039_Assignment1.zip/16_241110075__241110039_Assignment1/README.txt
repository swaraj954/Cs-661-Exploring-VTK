open cmd
change to this directory

to run part1.py in cmd type:

part1.py Isabel_2D.vti output_file_name.vtp isovalue



to run part2.py in cmd type:

(for phong shading off)
part2.py Isabel_3D.vti 0


(for phong shading on)
part2.py Isabel_3D.vti 1

