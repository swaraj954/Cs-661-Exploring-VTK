import vtk
import sys

# Function to interpolate a contour point along an edge  
def interpolate(point1,point2,value1,value2):
    if value1 == value2:
        return point1

    d= (isovalue-value1) / (value2 - value1)
    return [point1[0] + d * (point2[0] - point1[0]) ,point1[1] + d * (point2[1] - point1[1])]



def obtain_isocountour(in_file,out_file,isovalue):
    # Read the .vti file
    file_reader = vtk.vtkXMLImageDataReader()
    file_reader.SetFileName(in_file)
    file_reader.Update()

    # Get image data

    image_data=file_reader.GetOutput()
    dimensions=image_data.GetDimensions()
    spacing=image_data.GetSpacing()
    origin=image_data.GetOrigin()

    # Get scalar values
    point_values=image_data.GetPointData().GetScalars()


    # Create a PolyData object to store the isocontour
    contour_polydata_object=vtk.vtkPolyData()
    points=vtk.vtkPoints()
    lines=vtk.vtkCellArray()

    # Iterate through each cell (Nx-1 x Ny-1)
    
    for i in range(dimensions[0] - 1):
        for j in range(dimensions[1] - 1):
            point1 = i + j*dimensions[0]
            point2 = (i + 1) + j*dimensions[0]
            point3 = i+(j+1)*dimensions[0]
            point4 = (i+1) + (j+1)*dimensions[0]

            cord1 = [origin[0] + i * spacing[0], origin[1] + j * spacing[1]]
            cord2 = [origin[0] + (i + 1) * spacing[0], origin[1] + j * spacing[1]]
            cord3 = [origin[0] + i * spacing[0], origin[1] + (j + 1) * spacing[1]]
            cord4 = [origin[0] + (i + 1) * spacing[0], origin[1] + (j + 1) * spacing[1]]

            value_at_cord1 = point_values.GetTuple1(point1)
            value_at_cord2 = point_values.GetTuple1(point2)
            value_at_cord3 = point_values.GetTuple1(point3)
            value_at_cord4 = point_values.GetTuple1(point4)


            intersections = []
            # Determine which edges are intersected
            
            if (value_at_cord1 < isovalue and value_at_cord2 >=isovalue) or (value_at_cord1>=isovalue and value_at_cord2<isovalue):
                intersections.append(interpolate(cord1, cord2, value_at_cord1,value_at_cord2))
            if (value_at_cord2 < isovalue and value_at_cord4 >=isovalue) or (value_at_cord2>=isovalue and value_at_cord4<isovalue):
                intersections.append(interpolate(cord2, cord4, value_at_cord2,value_at_cord4))
            if (value_at_cord4 < isovalue and value_at_cord3 >=isovalue) or (value_at_cord4>=isovalue and value_at_cord3<isovalue):
                intersections.append(interpolate(cord4, cord3, value_at_cord4,value_at_cord3))
            if (value_at_cord3 < isovalue and value_at_cord1 >=isovalue) or (value_at_cord3>=isovalue and value_at_cord1<isovalue):
                intersections.append(interpolate(cord3, cord1, value_at_cord3,value_at_cord1))


            # If there are exactly 2 intersection points, store them as a contour segment
            
            if len(intersections)==2:
                segment1 = points.InsertNextPoint(intersections[0][0], intersections[0][1], 0)
                segment2 = points.InsertNextPoint(intersections[1][0],intersections[1][1],0)
                contour_line = vtk.vtkLine()
                contour_line.GetPointIds().SetId(0,segment1)
                contour_line.GetPointIds().SetId(1,segment2)
                lines.InsertNextCell(contour_line)
        
    # Store points and lines in vtkPolyData
               
    contour_polydata_object.SetPoints(points)
    contour_polydata_object.SetLines(lines)

    # Write output to .vtp file
    writer = vtk.vtkXMLPolyDataWriter()
    writer.SetFileName(out_file)
    writer.SetInputData(contour_polydata_object)
    writer.Write()

    print(f"Isocontour has been extracted and saved to this file: {out_file}")

    

# Check command-line arguments
if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python extract_contour.py <input.vti> <output.vtp> <isovalue>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]
    isovalue = float(sys.argv[3])

    obtain_isocountour(input_file, output_file, isovalue)



       


            
            


    
    




    
